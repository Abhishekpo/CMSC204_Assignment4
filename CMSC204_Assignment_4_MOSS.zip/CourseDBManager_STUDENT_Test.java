/**
 * @author Abhishek Poudel
 */
	import static org.junit.Assert.*;
	import java.io.File;
	import java.io.PrintWriter;
	import java.util.ArrayList;
	import org.junit.After;
	import org.junit.Before;
	import org.junit.Test;

	
	public class CourseDBManager_STUDENT_Test {
		private CourseDBManagerInterface dataMgr = new CourseDBManager();

		@Before
		public void setUp() throws Exception {
			dataMgr = new CourseDBManager();
		}

		@After
		public void tearDown() throws Exception {
			dataMgr = null;
		}

		@Test
		public void testAddToDB() {
			try {
				dataMgr.add("CMSC208", 65784, 4, "CM345", "Ram Poudel");
			} catch (Exception e) {
				fail("This should not have caused an Exception" );
			}
		}

		@Test
		public void testShowAll() {
			
			dataMgr.add("CMSC204", 66532, 4, "CM345", "Ram Poudel");
			dataMgr.add("CMSC204", 17381, 4, "MN345", "Ram Neupane");
			dataMgr.add("CMSC204", 33123, 4, "MP367", "Hari B Parsad");
			ArrayList<String> list = dataMgr.showAll();
			assertEquals(list.get(0), "\nCourse:CMSC204 CRN:66532 Credits:4 Instructor:Ram Poudel Room:CM345");
			assertEquals(list.get(1), "\nCourse:CMSC204 CRN:33123 Credits:4 Instructor:Hari B Parsad Room:MP367");
			assertEquals(list.get(2), "\nCourse:CMSC204 CRN:17381 Credits:4 Instructor:Ram Neupane Room:MN345");
                  
		}

		/**
		 * Test for the read method
		 */
		@Test
		public void testRead() {
			try {
				File inputFile = new File("StudentTest.txt");
				PrintWriter inFile = new PrintWriter(inputFile);
				inFile.println("CMSC205 23456 4 MN234 Hari Bhadur");
				inFile.print("CMSC204 34567 2 ML235 Ram Neupane");
				inFile.close();
				
				dataMgr.readFile(inputFile);
				assertEquals("CMSC205", dataMgr.get(23456).getID());
				assertEquals("CMSC204", dataMgr.get(34567).getID());
				assertEquals("ML235", dataMgr.get(34567).getRoomNum());
			} catch (Exception e) {
				fail("Should not have thrown an exception");
			}
		}
	}

