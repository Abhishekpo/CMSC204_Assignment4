	import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
/**
 * 
 * @author Abhishek Poudel
 *
 */
public class CourseDBStructure implements CourseDBStructureInterface
{
	protected int hashsize;
	protected ArrayList<LinkedList<CourseDBElement>>hashTable;
	private final double loadFactor=1.5;
	
	public CourseDBStructure(int n)
	{
		int num=(int) (n/loadFactor);
		
		for(int i=0; i<num; i++)
		{
			if((4*i+3)>num)
			{
				if(isPrime(4*i+3))
				{
				 this.hashsize= 4*i+3;
					break;
				}
			}
		}
	hashTable= new ArrayList<LinkedList<CourseDBElement>>(hashsize);
	for(int k=0; k< hashsize; k++)
	{
		hashTable.add(new LinkedList<CourseDBElement>());
	}
		
		
	}
	public CourseDBStructure(String testing, int n)
	{
		hashsize =n;
		hashTable= new ArrayList<LinkedList<CourseDBElement>>(hashsize);
		for(int k=0; k< hashsize; k++)
		{
			hashTable.add(new LinkedList<CourseDBElement>());
		}
	}
    public boolean isPrime(int n)
    {
    	if(n<=1)
    	{
    		return false;
    	}
    	else {
    	for(int i=2; i<n; i++)
    	{
    		if(n%i==0)
    		{
    			return false;
    		}
    
    	}
    	return true;
    	}
    }
	@Override
	public void add(CourseDBElement element) {
		int cds = element.getCRN() % hashsize;

		if (!(hashTable.get(cds).contains(element))) {
			hashTable.get(cds).add(element);
		}

		for (int i = 0; i < hashTable.get(cds).size(); i++) {
			//if (!((CourseDBElement) hashTable.get(cds).get(i)).getID().equals(element.getID())) {
				if (((CourseDBElement) hashTable.get(cds).get(i)).getCRN() == element.getCRN()) {
					hashTable.get(cds).remove(i);
					hashTable.get(cds).add(element);
				}
			}
		}
		
	//}

	@Override
	public CourseDBElement get(int crn) throws IOException {
		int index = crn % hashsize;

		if (!(hashTable.get(index).isEmpty())) {
			for (int i = 0; i < hashTable.get(index).size(); i++) {
				if (((CourseDBElement) hashTable.get(index).get(i)).getCRN() == crn) {
					return ((CourseDBElement) hashTable.get(index).get(i));
				}
			}
		}
		throw new IOException();
	}

	@Override
	public ArrayList<String> showAll() {
		ArrayList<String> cds = new ArrayList<String>();

		for (int i = 0; i < hashsize; i++) {
			if (!(hashTable.get(i).isEmpty())) {
				cds.add(hashTable.get(i).toString().replace("[", "").replace("]", ""));
			}
		}
		return cds;
	}

	@Override
	public int getTableSize() {
		// TODO Auto-generated method stub
	 return hashsize;
	}
 
}
