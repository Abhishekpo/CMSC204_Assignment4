/**
 * 
 * @author Abhishek Poudel
 *
 */
public class CourseDBElement implements Comparable<CourseDBElement>{
	String CourseID;
    int CRN;
    int credits;
    String roomNum;
    String instructorName;
    /**
     *  constructor to initialize the instances
     * @param id course id of the Course
     * @param crn CRN number of the Class
     * @param credits Credits of the class
     * @param roomNum Room number 
     * @param instName instructor name
     */
public CourseDBElement (String id, int crn, int credits, String roomNum, String instName)
{
	this.CourseID= id;
	this.CRN=crn;
	this.credits=credits;
	this.roomNum=roomNum;
	this.instructorName=instName;
}
/**
 * Default constructor
 */
public CourseDBElement() {
	this.CourseID=null;
	this.CRN=0;
	this.credits=0;
	this.roomNum=null;
	this.instructorName=null;
}
/**
 * 
 * @return return the hashcode from crn number
 */
  public int getHash() {
	int a = 31;
	int hash = 0;
	String str = String.valueOf(getCRN());
	for (int i = 0; i < str.length(); i++) {
		hash = a * hash + str.charAt(i);
	}
	return hash;
}
 
public void setId(String courseId)
{
	this.CourseID=courseId;
}
public String getID()
{
	return CourseID;
}
public void setCRN(int crn)
{
	this.CRN=crn;
}
public int getCRN()
{
	return CRN;
}
public void setCredits(int credits)
{
	this.credits=credits;
}
public int getCredits()
{
	return credits;
}
public void setRoomNum(String roomNum)
{
	this.roomNum=roomNum;
}
public String getRoomNum()
{
	return roomNum;
}
public void setInstructorName(String name)
{
	this.instructorName=name;
}
public String getInstructorName()
{
	return instructorName;
}

/**
 * ToString method
 */
@Override
public String toString() {
	String str = "\nCourse:" + CourseID + " CRN:" + CRN + " Credits:" + credits + " Instructor:" + instructorName
			+ " Room:" + roomNum;
	return str;
}
	@Override
	public int compareTo(CourseDBElement o) {
		if (o.CRN == CRN) {
			return 0;
		} else if (o.CRN < CRN) {
			return -1;
		} else {
			return 1;
		}
	}
 
}
